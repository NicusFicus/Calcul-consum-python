print("Alege functia programului:\nCalculare consum: [1]\nTransformare consum in alta metoda de masurat: [2]")
mile = 0
g = 0
x = int(input())

if x == 1:
    print("Litri: ")
    l = int(input())
    print("Kilometri: ")
    km = int(input())
else:
    print("Alege metoda de masurat curenta:\nKM/L: [1]\nL/100 KM: [2]\nMPG: [3]")
    t = int(input())

    if t == 1:
        print("Kilometri: ")
        km = int(input())
        print("Litri: ")
        l = int(input())

    elif t == 2:
        print("Litri: ")
        l = int(input())
        print("Kilometri: ")
        km = int(input())

    else:
        print("Mile: ")
        mile = int(input())
        print("Galoane: ")
        g = int(input())

if x == 1:
    print("Alege metoda de masurat:\nKM/L: [1]\nL/100 KM: [2]\nMPG: [3]")
else:
    print("Alege metoda de masurat noua:\nKM/L: [1]\nL/100 KM: [2]\nMPG: [3]")

z = int(input())

if mile != 0:
    km = mile * 1.6
    l = g * 3.9

if z == 1:
    print(f"KM/L: {km/l:.1f}")

elif z == 2:
    print(f"L/100 KM: {l/km*100:.1f}")

else:
    mile = km * 0.62
    g = l * 0.22
    print(f"MPG: {mile/g:.1f}")
